/*
 * File: stateflow_FMU_test_shrd_lib_capi.h
 *
 * Code generated for Simulink model 'stateflow_FMU_test_shrd_lib'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Wed Jun  1 19:19:05 2022
 *
 * Target selection: ert_shrlib.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_stateflow_FMU_test_shrd_lib_capi_h_
#define RTW_HEADER_stateflow_FMU_test_shrd_lib_capi_h_
#include "stateflow_FMU_test_shrd_lib.h"

extern void stateflow_FMU_test_shrd_lib_InitializeDataMapInfo(void);

#endif                      /* RTW_HEADER_stateflow_FMU_test_shrd_lib_capi_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
