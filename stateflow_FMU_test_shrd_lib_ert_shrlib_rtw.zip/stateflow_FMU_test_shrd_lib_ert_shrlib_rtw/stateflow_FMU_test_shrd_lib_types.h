/*
 * File: stateflow_FMU_test_shrd_lib_types.h
 *
 * Code generated for Simulink model 'stateflow_FMU_test_shrd_lib'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Wed Jun  1 19:19:05 2022
 *
 * Target selection: ert_shrlib.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_stateflow_FMU_test_shrd_lib_types_h_
#define RTW_HEADER_stateflow_FMU_test_shrd_lib_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_stateflow_FMU_test_sh_T RT_MODEL_stateflow_FMU_test_s_T;

#endif                     /* RTW_HEADER_stateflow_FMU_test_shrd_lib_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
