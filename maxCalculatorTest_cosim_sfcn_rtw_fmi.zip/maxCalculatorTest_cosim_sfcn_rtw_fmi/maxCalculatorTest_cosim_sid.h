/*
 * maxCalculatorTest_cosim_sid.h
 *
 * Code generation for model "maxCalculatorTest_cosim_sf".
 *
 * Model version              : 1.7
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Thu Jun  2 19:16:36 2022
 *
 * Target selection: rtwsfcnfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 *
 * SOURCES: maxCalculatorTest_cosim_sf.c
 */

/* statically allocated instance data for model: maxCalculatorTest_cosim */
{
  {
    /* Local SimStruct for the generated S-Function */
    static LocalS slS;
    LocalS *lS = &slS;
    ssSetUserData(rts, lS);

    /* model checksums */
    ssSetChecksumVal(rts, 0, 2245049582U);
    ssSetChecksumVal(rts, 1, 1426956571U);
    ssSetChecksumVal(rts, 2, 1892112300U);
    ssSetChecksumVal(rts, 3, 2594695460U);
  }
}
