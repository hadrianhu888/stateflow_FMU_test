/*
 * maxCalculatorTest_sid.h
 *
 * Code generation for model "maxCalculatorTest_sf".
 *
 * Model version              : 1.5
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Thu Jun  2 19:04:14 2022
 *
 * Target selection: rtwsfcnfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 *
 * SOURCES: maxCalculatorTest_sf.c
 */

/* statically allocated instance data for model: maxCalculatorTest */
{
  {
    /* Local SimStruct for the generated S-Function */
    static LocalS slS;
    LocalS *lS = &slS;
    ssSetUserData(rts, lS);

    /* model checksums */
    ssSetChecksumVal(rts, 0, 1044411538U);
    ssSetChecksumVal(rts, 1, 3456578291U);
    ssSetChecksumVal(rts, 2, 1449229105U);
    ssSetChecksumVal(rts, 3, 4260785677U);
  }
}
