/*
 * stateflow_FMU_test_mod_stdfmi_types.h
 *
 * Code generation for model "stateflow_FMU_test_mod_stdfmi".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Wed Jun  1 19:12:21 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_stateflow_FMU_test_mod_stdfmi_types_h_
#define RTW_HEADER_stateflow_FMU_test_mod_stdfmi_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_stateflow_FMU_test_mo_T RT_MODEL_stateflow_FMU_test_m_T;

#endif                   /* RTW_HEADER_stateflow_FMU_test_mod_stdfmi_types_h_ */
