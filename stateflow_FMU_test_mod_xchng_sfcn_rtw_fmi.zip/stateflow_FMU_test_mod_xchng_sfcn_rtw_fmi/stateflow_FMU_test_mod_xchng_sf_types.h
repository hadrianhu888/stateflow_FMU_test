/*
 * stateflow_FMU_test_mod_xchng_sf_types.h
 *
 * Code generation for model "stateflow_FMU_test_mod_xchng_sf".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Wed Jun  1 19:10:17 2022
 *
 * Target selection: rtwsfcnfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_stateflow_FMU_test_mod_xchng_sf_types_h_
#define RTW_HEADER_stateflow_FMU_test_mod_xchng_sf_types_h_

/* Model Code Variants */
#endif                 /* RTW_HEADER_stateflow_FMU_test_mod_xchng_sf_types_h_ */
