/*
* Generated S-function Target for model maxCalculatorTest_cosim.
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Thu Jun  2 19:06:03 2022
*/

#ifndef RTWSFCN_maxCalculatorTest_cosim_sf_H
#define RTWSFCN_maxCalculatorTest_cosim_sf_H

#include "maxCalculatorTest_cosim_sfcn_rtw\maxCalculatorTest_cosim_sf.h"
    #include "maxCalculatorTest_cosim_sfcn_rtw\maxCalculatorTest_cosim_sf_private.h"

#endif
