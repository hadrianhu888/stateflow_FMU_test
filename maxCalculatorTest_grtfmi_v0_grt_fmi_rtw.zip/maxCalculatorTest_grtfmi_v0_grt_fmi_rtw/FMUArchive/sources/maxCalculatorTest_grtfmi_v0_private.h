/*
 * maxCalculatorTest_grtfmi_v0_private.h
 *
 * Code generation for model "maxCalculatorTest_grtfmi_v0".
 *
 * Model version              : 1.7
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Thu Jun  2 19:13:37 2022
 *
 * Target selection: grtfmi.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_maxCalculatorTest_grtfmi_v0_private_h_
#define RTW_HEADER_maxCalculatorTest_grtfmi_v0_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#endif                   /* RTW_HEADER_maxCalculatorTest_grtfmi_v0_private_h_ */
