/*
* Generated S-function Target for model maxCalculatorTest.
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Thu Jun  2 19:04:14 2022
*/

#ifndef RTWSFCN_maxCalculatorTest_sf_H
#define RTWSFCN_maxCalculatorTest_sf_H

#include "maxCalculatorTest_sfcn_rtw\maxCalculatorTest_sf.h"
    #include "maxCalculatorTest_sfcn_rtw\maxCalculatorTest_sf_private.h"

#endif
