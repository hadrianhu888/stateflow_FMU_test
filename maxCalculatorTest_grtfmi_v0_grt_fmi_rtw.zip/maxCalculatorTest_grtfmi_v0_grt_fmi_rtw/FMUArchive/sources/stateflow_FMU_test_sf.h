/*
* Generated S-function Target for model stateflow_FMU_test.
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Wed Jun  1 19:07:36 2022
*/

#ifndef RTWSFCN_stateflow_FMU_test_sf_H
#define RTWSFCN_stateflow_FMU_test_sf_H

#include "stateflow_FMU_test_sfcn_rtw\stateflow_FMU_test_sf.h"
    #include "stateflow_FMU_test_sfcn_rtw\stateflow_FMU_test_sf_private.h"

#endif
